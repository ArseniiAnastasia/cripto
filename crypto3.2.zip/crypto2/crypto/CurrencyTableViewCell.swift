//
//  CurrencyTableViewCell.swift
//  crypto
//
//  Created by Air on 6/18/21.
//  Copyright © 2021 Air. All rights reserved.
//

import UIKit

class CurrencyTableViewCell: UITableViewCell {

    @IBOutlet var nameCurrency: UILabel!
    
    @IBOutlet var price: UILabel!
    
    @IBOutlet weak var percent: UILabel!
    
    @IBOutlet weak var imagePercent: UIImageView!
    
    func configure(with bitcoins: Bitcoin) {
        self.nameCurrency.text = bitcoins.currency.bitcoinSymbol
        self.price.text =  bitcoins.currency.currencySymbol + "\(bitcoins.currentPrice)"
        if bitcoins.percent() < 0 {
            self.percent.text = "\(bitcoins.percent())%"
            self.imagePercent.image = UIImage(named: "down")
        } else {
            self.percent.text = "+\(bitcoins.percent())%"
            self.imagePercent.image = UIImage(named: "up")
        }
       
    }
}
