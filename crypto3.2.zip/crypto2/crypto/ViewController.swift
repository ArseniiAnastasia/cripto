//
//  ViewController.swift
//  crypto
//
//  Created by Air on 5/31/21.
//  Copyright © 2021 Air. All rights reserved.
//

import UIKit
import Charts

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
   
    @IBOutlet var tableView: UITableView!
    
    var currencyDetail: ((Bitcoin) -> Void)? = nil
    
    var currencies: [String] {
        set {
            UserDefaults.standard.set(newValue, forKey: "newCurrency")
            UserDefaults.standard.synchronize()
        }
        get {
            if let array = UserDefaults.standard.array(forKey: "newCurrency")
                as? [String] {
                return array
            } else {
                return []
            }
        }
    }
    
    var bitcoins = [Bitcoin]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self

        
        let date = Date()
        // Создаем и настраиваем форматор дат
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE MMM d"
        let dateString = dateFormatter.string(from: date)
        
        let leftItem = UIBarButtonItem(title: dateString,
                                       style: UIBarButtonItemStyle.plain,
                                       target: nil,
                                       action: nil)
        leftItem.isEnabled = false
        self.navigationItem.leftBarButtonItem = leftItem
        
        updateTableData()
    }
    
    private func getBicoinValues(for currency: BitcoinCurrency, completion: @escaping (Bitcoin) -> Void) {
        let parameters = BitcoinAPIParameters(currency: currency, interval: "1d", limit: 30)
        BitcoinAPI(parameters: parameters)
            .sendRequest { result, error in
                guard error == nil else {
                    print(error)
                    return
                }
                
                guard let result = result else { return }
                // Массив из цен на каждый день
                let prices = result.compactMap { $0 }
                    .compactMap { $0[4] as? String }
                    .map { Double($0) ?? 0 }
                // Массив из дат на каждый день, нужны чтоб сортировать цены
                let dates = result.compactMap { $0 }
                    .compactMap { $0[6] as? Double }
                    .map { Date(timeIntervalSince1970: .init($0 / 1000)) }
                // Конвертация цен и дат в массив из Bitcoin Price
                let values = zip(dates, prices).map { BitcoinPrice(date: $0.0, price: $0.1) }
                
                completion(Bitcoin(prices: values, currency: currency))
            }
        
    }
    
    private func updateTableData() {
        bitcoins.removeAll()
        
        for selectedCurrency in currencies {
            getBicoinValues(for: BitcoinCurrency(rawValue: selectedCurrency) ?? .usd, completion: { bitcoin in
                self.bitcoins.append(bitcoin)
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            })
        }
    }
    
    @IBAction func didTapNewCurrency() {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "new") as? NewViewController else {
            return
        }
        vc.title = "Choose a currency"
        vc.currencySelected = { currency in
            guard !self.currencies.contains(currency) else { return }
            self.currencies.append(currency)
            self.navigationController?.popToRootViewController(animated: true)
            
            self.updateTableData()
        }
        
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bitcoins.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! CurrencyTableViewCell
        
          //cell.textLabel?.text = currencies[indexPath.row]
          //cell.textLabel?.text = bitcoins[indexPath.row].currency.rawValue
        
          //cell.detailTextLabel?.text = "\(bitcoins[indexPath.row].currentPrice)"
        
        cell.configure(with: bitcoins[indexPath.row])
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       showMiracle(with: bitcoins[indexPath.row])
        
        
    }
    
    func showMiracle(with bitcoin: Bitcoin) {
        let slideVC = ChartsView()
        //let slideVC = UIViewController(nibName: "ChartsView", bundle: nil)
        slideVC.modalPresentationStyle = .custom
        slideVC.transitioningDelegate = self
        self.present(slideVC, animated: true, completion: nil)
        slideVC.conf(with: bitcoin)
        //self.navigationController?.pushViewController(slideVC, animated: true)
    }

    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let bitcoinCurrency = bitcoins[indexPath.row].currency.rawValue
            currencies.enumerated().forEach { index, currency in
                if bitcoinCurrency == currency {
                    currencies.remove(at: index)
                }
            }
            
            updateTableData()
        }
    }
}


struct BitcoinPrice {
    
    var date: Date
    var price: Double
    
}

struct Bitcoin {
    
    var prices: [BitcoinPrice]
    var currency: BitcoinCurrency
    
    var currentPrice: Double {
        return prices.last?.price ?? 0
    }
    
    var yesterdayPrice: Double {
        var yesterdayPrice: Double = 0
        
        prices.forEach { price in
            if price.date.isYesterday {
                yesterdayPrice = price.price
            }
        }
        return yesterdayPrice
    }
    
    func percent() -> Double {
        var percent = ((currentPrice - yesterdayPrice)/((currentPrice+yesterdayPrice)/2))*100
        percent = Double(round(100*percent)/100)
        return percent
    }

}
struct BitcoinAPIParameters {
    
    var currency: BitcoinCurrency = .usd
    var interval: String = "1d"
    var limit: Int = 30
}

struct BitcoinAPI {
    
    private let baseURL = "https://api.binance.com/api/v3/klines"
  
    var parameters: BitcoinAPIParameters
    
    private var urlComponents: URLComponents? {
        var urlComponents = URLComponents(string: baseURL)
        urlComponents?.queryItems = [
            URLQueryItem(name: "symbol", value: parameters.currency.bitcoinSymbol),
            URLQueryItem(name: "interval", value: parameters.interval),
            URLQueryItem(name: "limit", value: String(parameters.limit))
        ]
        
        return urlComponents
    }
    
    init(parameters: BitcoinAPIParameters) {
        self.parameters = parameters
    }
    
    func sendRequest(completion: @escaping ([[Any]]?, Error?) -> Void) {
        guard let urlComponents = urlComponents, let url = urlComponents.url?.absoluteURL else {
            completion(nil, NSError())
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data,
                  let response = response as? HTTPURLResponse,
                  (200 ..< 300) ~= response.statusCode,
                  error == nil else {
                    completion(nil, error)
                    return
            }
            let responseObject = (try? JSONSerialization.jsonObject(with: data)) as? [[Any]]
            completion(responseObject, nil)
        }
        
        task.resume()
    }
}

enum BitcoinCurrency: String, Codable {
    
    case usd = "USD"
    case eur = "EUR"
    case gbp = "GBP"
    
    var currencySymbol: String {
        switch self {
        case .usd:
            return "$"
        case .eur:
            return "€"
        case .gbp:
            return "£"
        }
    }
    
    var bitcoinSymbol: String {
        switch self {
        case .usd:
            return "BTCUSDT"
        case .eur:
            return "BTCEUR"
        case .gbp:
            return "BTCGBP"
        }
    }
    
   // static let `default` = BitcoinCurrency.usd
    
    
    }

extension Date {
    var isYesterday: Bool {
        return NSCalendar.current.isDateInYesterday(self)
    }
}

extension ViewController: UIViewControllerTransitioningDelegate {
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        return PresentationController(presentedViewController: presented, presenting: presenting)
    }
}
    








    



